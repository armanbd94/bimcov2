<?php

return [
    'name' => 'Customer'
];
