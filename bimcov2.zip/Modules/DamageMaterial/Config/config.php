<?php

return [
    'name' => 'DamageMaterial'
];
