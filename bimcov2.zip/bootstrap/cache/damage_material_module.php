<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\DamageMaterial\\Providers\\DamageMaterialServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\DamageMaterial\\Providers\\DamageMaterialServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);