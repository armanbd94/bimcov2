<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Stock\\Providers\\StockServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Stock\\Providers\\StockServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);