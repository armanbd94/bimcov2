<?php

return [
    'name' => 'Expense'
];
