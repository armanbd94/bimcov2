<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Material\\Providers\\MaterialServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Material\\Providers\\MaterialServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);