<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Formulation\\Providers\\FormulationServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Formulation\\Providers\\FormulationServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);