<?php

return [
    'name' => 'MobileBank'
];
