<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Expense\\Providers\\ExpenseServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Expense\\Providers\\ExpenseServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);