<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\MobileBank\\Providers\\MobileBankServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\MobileBank\\Providers\\MobileBankServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);