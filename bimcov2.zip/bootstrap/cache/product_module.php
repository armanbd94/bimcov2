<?php return array (
  'providers' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
  ),
  'eager' => 
  array (
    0 => 'Modules\\Product\\Providers\\ProductServiceProvider',
  ),
  'deferred' => 
  array (
  ),
);